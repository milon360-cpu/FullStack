import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';
import AppController from './AppController/AppController';

function App() {
  return (
    <div className="App">
      <AppController />
    </div>
  );
}

export default App;
