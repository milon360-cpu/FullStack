import React from 'react';
import Fade from 'react-reveal/Fade'
import './Idea.css'
import video from './video.mp4'
const Idea = () => {
    return (
        <div className='container mt-5'>
            <div className="row">
                <div className="col-sm-12 col-lg-8">
                 <Fade top>
                    <div className="idea-details">

                        <h1>Development</h1>
                        <p>
                            Lorem ipsum dolor sit amet consectetur, adipisicing elit. Magnam possimus, aut dolor perferendis est illum dolorem nesciunt, aliquid maxime cupiditate maiores nihil officia provident odit ad iusto corrupti assumenda. Corrupti libero eveniet doloribus? Sunt suscipit nemo voluptates modi mollitia laudantium eius voluptas facilis quo, rem soluta. Dignissimos placeat cum et, facere accusamus suscipit accusantium perspiciatis adipisci commodi ipsam unde nostrum consectetur esse nemo deleniti provident doloribus sunt sint perferendis totam beatae doloremque minima minus maxime? Labore similique excepturi aspernatur nulla aliquam dignissimos? Earum voluptatem dolorum animi at nemo in non beatae obcaecati dolore. Deleniti perferendis provident tenetur soluta labore ut?
                        </p>
                    </div>
                    </Fade>
                </div>
                <div className="col-sm-12 col-lg-4">
                    <div className="idea-vide-container ">
                        <video autoPlay  muted loop>
                            <source  src={video} />
                        </video>
                    </div>
                </div>   
            </div>
        </div>
    );
};

export default Idea;