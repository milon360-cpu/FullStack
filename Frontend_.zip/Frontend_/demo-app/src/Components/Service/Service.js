import React,{useState} from 'react';
import Fade from 'react-reveal/Fade';
import './Service.css'
const Service = () => {
    return (
        <div className='container mt-5 mb-5'>
            <h2 className='service-header'>Services</h2>
            <div className="row">
                <div className="col-sm-12 col-lg-4">
                    <Fade left>
                    <div className="service">
                        <h2>Web Design</h2>
                        <p>
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Officiis commodi neque nisi fugiat laborum modi magnam voluptatem doloremque aliquid hic!
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Officiis commodi neque nisi fugiat laborum modi magnam voluptatem doloremque aliquid hic!</p>
                    </div>
                    </Fade>
                </div>
                <div className="col-sm-12 col-lg-4">
                  <Fade top>
                    <div className="service">
                       <h2>Web Development</h2>
                       <p>
                        Lorem, ipsum dolor sit amet consectetur adipisicing elit. Reiciendis, nulla sequi similique perspiciatis optio repellat cupiditate dolorem. Officiis, iusto distinctio.
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Officiis commodi neque nisi fugiat laborum modi magnam voluptatem doloremque aliquid hic!
                       </p>
                    </div>
                    </Fade>
                </div>
                <div className="col-sm-12 col-lg-4">
                  <Fade right>
                    <div className="service">
                      <h2>Android Development</h2>
                      <p>
                        Lorem ipsum, dolor sit amet consectetur adipisicing elit. Autem nisi deserunt incidunt eius consectetur possimus nam veniam consequuntur reprehenderit eveniet?
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Officiis commodi neque nisi fugiat laborum modi magnam voluptatem doloremque aliquid hic!
                      </p>
                    </div>
                    </Fade>
                </div>
            </div>
        </div>
    );
};

export default Service;