import React from 'react';
import './OurTeam.css'
import img1 from './TeamImage/img1.jpg'
import img2 from './TeamImage/img2.jpg'
import img3 from './TeamImage/img3.jpg'
import Fade from 'react-reveal/Fade';
const OurTeam = () => {
    return (
        <div className='container'>
            <h2 className='text-center text-primary'>Our Team</h2>
            <div className="row mt-5">
                <div className="col-sm-12 col-lg-4">
                    <Fade top>
                    <div className="team-member">
                        <div className="tem-image">
                        <img src={img1} alt="" />
                        </div>
                        <div className="team-details">
                         <h4 className='text-center mt-3'>Naiok Manna</h4>
                         <p>
                            Lorem ipsum, dolor sit amet consectetur adipisicing elit. Necessitatibus dolorem culpa iusto fuga omnis et dolor ipsa, quia commodi quae!
                         </p>
                        </div>
                    </div>
                    </Fade>
                </div>
                <div className="col-sm-12 col-lg-4">
                   <Fade top>
                    <div className="team-member">
                        <div className="tem-image">
                        <img src={img2} alt="" />
                        </div>
                        <div className="team-details">
                          <h4 className='text-center mt-3'>Naiok Omorsani</h4>
                          <p>
                            Lorem ipsum, dolor sit amet consectetur adipisicing elit. Necessitatibus dolorem culpa iusto fuga omnis et dolor ipsa, quia commodi quae!
                          </p>
                        </div>
                    </div>
                    </Fade>
                </div>
                <div className="col-sm-12 col-lg-4">
                  <Fade top>
                   <div className="team-member">
                        <div className="tem-image">
                        <img src={img3} alt="" />
                        </div>
                        <div className="team-details">
                          <h4 className='text-center mt-3'>Naiok Dipjol</h4>
                           <p>
                            Lorem ipsum, dolor sit amet consectetur adipisicing elit. Necessitatibus dolorem culpa iusto fuga omnis et dolor ipsa, quia commodi quae!
                           </p>
                        </div>
                    </div>
                    </Fade>
                </div>
            </div>
        </div>
    );
};

export default OurTeam;