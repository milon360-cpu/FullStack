import React, { useEffect, useState } from 'react';
import { FaDatabase,FaNode,FaNodeJs,FaReact } from "react-icons/fa";
import mongo from '../Images/mongo.png'
import express from '../Images/express.png'
import node from '../Images/node.png'
import react from '../Images/react.png'
import Fade from 'react-reveal/Fade';

import './Banner.css'

const Banner = () => {
  
    return (
        <div className='banner-container'>
            <Fade bottom>
            <h1>MERN</h1>
            <p>
               Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptatem distinctio blanditiis aperiam beatae incidunt repellendus deserunt necessitatibus nisi. Nihil, molestiae?
               Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptatem distinctio blanditiis aperiam beatae incidunt repellendus deserunt necessitatibus nisi. Nihil, molestiae?
            </p>
            </Fade>
           
          <div id="carouselExampleSlidesOnly" class="carousel slide" data-bs-ride="carousel">
            <div class="carousel-inner mt-5" data-bs-interval="1000">
              <div class="carousel-item active"  data-bs-interval="2000">
                <img src={mongo} class="d-block w-100" alt="..." />
               </div>
               <div class="carousel-item"  data-bs-interval="2000">
                 <img src={express} class="d-block w-100" alt="..." />
               </div>
               <div class="carousel-item"  data-bs-interval="2000">
                 <img src={react} class="d-block w-100" alt="..." />
                </div>
                <div class="carousel-item"  data-bs-interval="2000">
                  <img src={node} class="d-block w-100" alt="..." />
                </div>
             </div>
          </div>
        </div>
    );
};

export default Banner;