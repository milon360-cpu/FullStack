import React from 'react';
import img1 from './images/image1.jpg';
import img2 from './images/image2.jpg';
import img3 from './images/image3.jpg';
import img4 from './images/image4.jpg';
import img5 from './images/imag5.jpg';
import img6 from './images/image6.jpg';
import Fade from 'react-reveal/Fade';
import './ImmageGallery.css'
const ImmageGallery = () => {
    return (
        <div className='container mt-5'>
            <div className="row">
                <div className="col-sm-12 col-lg-4">
                    <Fade left>
                        <div className="image">
                            <img src={img1} alt="" />
                        </div>
                    </Fade>
                </div>  
                <div className="col-sm-12 col-lg-4">
                 <Fade bottom>
                   <div className="image">
                        <img src={img2} alt="" />
                    </div>
                 </Fade > 
                </div>
                <div className="col-sm-12 col-lg-4">
                <Fade right>
                    <div className="image">
                        <img src={img3} alt="" />
                    </div>
                </Fade>
                </div>
            </div>
            <div className="row">
                <div className="col-sm-12 col-lg-4">
                    <Fade top>
                        <div className="image">
                            <img src={img4} alt="" />
                        </div>
                    </Fade>
                </div>  
                <div className="col-sm-12 col-lg-4">
                 <Fade right>
                   <div className="image">
                        <img src={img5} alt="" />
                    </div>
                 </Fade > 
                </div>
                <div className="col-sm-12 col-lg-4">
                <Fade top>
                    <div className="image">
                        <img src={img6} alt="" />
                    </div>
                </Fade>
                </div>
            </div>
        </div>
    );
};

export default ImmageGallery;