import React from 'react';
import {Navigate, NavLink} from 'react-router-dom'
import { FaLaptopHouse, FaBlenderPhone,FaWarehouse,FaFacebook,FaFacebookMessenger,FaGithubSquare,FaTwitter} from "react-icons/fa";
import Fade from 'react-reveal/Fade';
import './Footer.css'

const Footer = () => {
    return (
        <div className='footer-container'>
            <div className="container">
                <div className="row">
                    <div className="col-sm-4 col-lg-4">
                       <Fade left>
                        <div className="Contact">
                           <h3>Contact</h3>

                            <FaLaptopHouse className='fs-4 text-white'></FaLaptopHouse> 
                            <span>45/B Dhanmondi Rode-15  Dhaka</span><br />
                            <FaBlenderPhone className='fs-4 text-white'/>
                            <span >01771341302</span><br />
                            <FaWarehouse className='fs-4 text-white'/>
                            <span >heymilon@gmail.com</span>
                        </div>
                       </Fade>
                    </div>
                    <div className="col-sm-4 col-lg-4">
                        <Fade top>
                        <div className="quick-access">
                            <h3>Quick Access</h3>
                             <ul>
                                <li><a href=""><FaFacebook className='social'></FaFacebook></a></li>
                                <li><a href=""><FaFacebookMessenger className='social'/></a></li>
                                <li><a href=""><FaGithubSquare className='social'/></a></li>
                                <li><a href=""><FaTwitter className='social'/></a></li>
                             </ul>
                        </div>
                        </Fade>
                    </div>
                    <div className="col-sm-4 col-lg-4">
                      <Fade right>
                        <div className="footer-service">
                            <h3>service</h3>
                            <ul>
                                <li><a href="">Web Design</a></li>
                                <li><a href="">Web Development</a></li>
                                <li><a href="">Android Development</a></li>
                            </ul>
                        </div>
                        </Fade>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Footer;