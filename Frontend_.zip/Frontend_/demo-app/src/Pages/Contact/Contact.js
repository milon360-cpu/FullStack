import React from 'react';
import map  from './map.png'
import Fade from 'react-reveal/Fade';
import { FaHouseUser,FaBlenderPhone,FaWarehouse,FaFacebook,FaGooglePlus,FaGithub,FaTwitter} from "react-icons/fa";
import './Contact.css'
const Contact = () => {
    return (
        <div className='container mt-5 mb-5'>
            
            <div className="contact-container">
                <div className="row">
                    <div className="col-sm-12 col-lg-12">
                        <Fade top>          
                        <div className="map-container">
                            <img src={map} alt="" />
                        </div>   
                        </Fade>                
                    </div>
                </div>
                <Fade bottom>
                <div className="form-container mt-5">
                    <h5>Write Your Message Here</h5>
                    <textarea className='form-control w-75 contact-textarea' name="" id="" cols="30" rows="10" placeholder='message' maxLength={150}></textarea>
                    <button className='btn btn-primary w-75 mt-4'>Submit</button>
                </div>
                </Fade>
            </div>
            
        </div>
    );
};

export default Contact;