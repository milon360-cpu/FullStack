import React,{useContext, useState} from 'react';
import './Register.css'
import Slide from 'react-reveal/Slide';
const URL = 'http://localhost:4000/user/registration';
const Register = () => {
  const [user,setUser] = useState
   
    (
      {
        name : '',
        email: '',
        gender: '',
        choose:'',
        file :''
      }
    )
    const handelChange = (e)=>
    {
        setUser({...user,[e.target.name]:e.target.value});
    }
    const handelSubmit = (e)=>
    {
        e.preventDefault();  
        fetch(URL,
          {
              method: "POST",
              headers : 
              {
                  "Content-Type" : "application/json"
              },
              body:JSON.stringify(user)
          })
          .then((response)=>
          {
              if(response.status === 201)
              {
                 alert("send Successfully");
              } 
              else 
              {
                  throw new Error ("user creation failed");
              }
          })
          .catch((error)=>
          {
             alert(error.message);
          })

          setUser(
            {
              name : '',
              email: '',
              gender: '',
              choose:'',
              file :''
            }
          )
    }
    return (
        <Slide top>
       <div className="register-form container mt-5 mb-5">
       
        <h3>Registration Form</h3>
         <form action="" onSubmit={handelSubmit}>
            <div className="form-group">
                <label htmlFor="name">Name <span className='text-danger'>*</span></label>
                <input type="text"  className='form-control w-75' placeholder='username' name = "name" onChange={handelChange} value = {user.name} required/>
            </div>
            <div className="form-group mt-2">
                <label htmlFor="">Email<span className='text-danger'> *</span></label>
                <input type="email"  className='form-control w-75' placeholder='@gmail.com' name = "email" onChange={handelChange} value = {user.email} required/>
            </div>
            <div className="form-group mt-2">
                <p className='mt-2'>Gender <span className='text-danger'> *</span></p>
                <input type="radio"  className='form-check-input me-2' name="gender"   value={"male"} onChange={handelChange} required/>
                <label class="form-check-label me-2" for="flexRadioDefault2">Male</label>
                <input type="radio"  className='form-check-input me-2' name="gender" value={"female"} onChange={handelChange} required/>
                <label class="form-check-label me-2" for="flexRadioDefault2">Female</label>
                <input type="radio"  className='form-check-input me-2' name="gender" value={"others"} onChange={handelChange} required/>
                <label class="form-check-label" for="flexRadioDefault2">Others</label>
            </div>
            <div className="form-group mt-3">
              <select class="form-select w-75" id="inputGroupSelect02" name = "choose" onChange={handelChange}  >
                <option selected name = "choose">Choose...</option>
                <option  name = "uoda" >UODA</option>
                <option value="GUB"  >GUB</option>
                <option value="AIUB"  >AIUB</option>
             </select>
              <div className="form-group mt-3">
                <input type="file"  className='form-control me-2 w-75' name="file" value = {user.file}onChange={handelChange} required/>
              </div>
              <div className="form-group mt-4">
                <button type='submit' className='btn btn-primary w-25 me-4 fw-bolder mt-3'>submit</button>
                <button type='reset'className='btn btn-warning w-25 fw-bolder mt-3'>reset</button>
              </div> 
            </div>
         </form>
        
       </div>
      
       </Slide>
    );
};

export default Register;