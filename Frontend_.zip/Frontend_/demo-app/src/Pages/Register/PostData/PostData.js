import React from 'react';
const PostData = (props) => {
    
    const creauseUser = (user)=>
    {
      console.log(props);
    }
    return (
        <div >
            
        </div>
    );
};

export default PostData;