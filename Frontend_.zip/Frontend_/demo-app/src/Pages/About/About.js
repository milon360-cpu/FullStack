import React from 'react';
import  ImmaageGallery from "../../Components/ImameGallery/ImmageGallery"
import Slide from 'react-reveal/Slide';
import './About.css'
const About = () => {
    return (
        <div className='container mb-5'>
            <Slide bottom>
           <div className="our-history mt-5 mb-5">
             <h2>Our History</h2>
             <p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Veniam quae est corrupti asperiores nemo dolorum aspernatur, quaerat dolor vel ut consectetur possimus perspiciatis quam rerum aut iure esse expedita quibusdam soluta quisquam? Iste at nesciunt inventore cum ipsam atque temporibus doloremque delectus molestias aliquam corporis eaque perferendis nobis, eos est iusto fugiat provident? Nesciunt modi deleniti mollitia expedita vero eius labore laboriosam quod. Accusamus similique ullam dicta dolorum, voluptate doloribus rem? Maxime nesciunt assumenda eos deserunt porro amet quam earum itaque dignissimos impedit. Porro tempora placeat atque, a quis sequi dolorum minima sunt sint repellendus cumque nulla itaque ab impedit.
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Veniam quae est corrupti asperiores nemo dolorum aspernatur, quaerat dolor vel ut consectetur possimus perspiciatis quam rerum aut iure esse expedita quibusdam soluta quisquam? Iste at nesciunt inventore cum ipsam atque temporibus doloremque delectus molestias aliquam corporis eaque perferendis nobis, eos est iusto fugiat provident? Nesciunt modi deleniti mollitia expedita vero eius labore laboriosam quod. Accusamus similique ullam dicta dolorum, voluptate doloribus rem? Maxime nesciunt assumenda eos deserunt porro amet quam earum itaque dignissimos impedit. Porro tempora placeat atque, a quis sequi dolorum minima sunt sint repellendus cumque nulla itaque ab impedit.
             </p>
             <ul>
                <li>Web Design</li>
                <li>Web Development</li>
                <li>Andriod Development</li>
             </ul>
             <p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Sequi recusandae fugit obcaecati animi, incidunt placeat officia corporis? Est laboriosam iusto aperiam ea optio hic esse qui, in ex quidem, suscipit exercitationem dolores id sint necessitatibus voluptatibus tempora vel labore assumenda mollitia. Ipsum veritatis expedita commodi, provident similique nam placeat autem!
             </p>
           </div>
           </Slide>
           <ImmaageGallery></ImmaageGallery>

        </div>
    );
};

export default About;