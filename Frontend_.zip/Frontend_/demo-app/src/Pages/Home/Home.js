import React from 'react';
import Banner from '../../Components/Banner/Banner';
import Idea from '../../Components/Idea/Idea';
import ImmageGallery from '../../Components/ImameGallery/ImmageGallery';
import OurTeam from '../../Components/OurTeam/OurTeam';
import Service from '../../Components/Service/Service';

const Home = () => {
    return (
        <div>
            <Banner></Banner>
            <ImmageGallery />
            <Idea />
            <Service />
            <OurTeam />
        </div>
    );
};

export default Home;