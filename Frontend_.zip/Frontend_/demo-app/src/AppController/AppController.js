import React from 'react';
import Footer from '../Footer/Footer';
import Navigation from '../Headers/Navigations/Navigation';
import Routing from '../Headers/Routing/Routing';
import About from '../Pages/About/About';

const AppController = () => {
    return (
        <div>
            <Routing></Routing>
            <Footer></Footer>
        </div>
    );
};

export default AppController;