import React from 'react';
import { BrowserRouter,Routes,Route } from 'react-router-dom';
import Contact from '../../Pages/Contact/Contact';
import Home from '../../Pages/Home/Home';
import Register from '../../Pages/Register/Register';
import Navigation from '../Navigations/Navigation';
import About from './../../Pages/About/About';
const Routing = () => {
    return (
        <>
            <BrowserRouter>
              <Navigation />
              <Routes>
                <Route path='/' element = {<Home />}></Route>
                <Route path='/about' element = {<About />}></Route>
                <Route path='/contact' element = {<Contact />}></Route>
                <Route path='/register' element = {<Register />}></Route>
              </Routes>
            </BrowserRouter>
        </>
    );
};

export default Routing;