const mongoose = require('mongoose');

const usersDocument = mongoose.Schema
(
    {
       name:
       {
        type : String,
        require : true
       },
       email:
       {
        type : String,
        require : true,
        unique : true
       },
       gender:
       {
        type:String,
        require:true
       },
       choose:
       {
         type : String,
         require: true
       },
       file:
       {
         type : String,
         require:true
       },
       onSubmit:
       {
         type : Date,
         default :Date.now
       }

    }
)

module.exports = mongoose.model("userCollections",usersDocument);