const { json } = require('body-parser');
const express = require('express');
const { getAllUser } = require('../Controller/userController');
const router = express.Router();
router.use(express.urlencoded({extended: true}));
router.use(json());

router.post('/user/registration',getAllUser)


module.exports = router;