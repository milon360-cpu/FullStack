const usersDocument = require('../Model/Model')
exports.getAllUser = async (req,res)=>
{
    try 
    {
        const newUser = new usersDocument(
            {
                name : req.body.name,
                email : req.body.email,
                gender: req.body.gender,
                choose: req.body.choose,
                file: req.body.file
            })
             await newUser.save();
             res.status(201).send("created Successfully");
    } 
    catch(error)
    {
       res.status(500).send(error.message);
    }
 
  
}