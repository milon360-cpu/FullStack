const express = require('express');
const router = require('./Routes/routes');
const cors = require('cors');
require('./Config/db');
const app = express();
app.use(cors());

app.use(router);
// error routing here 
app.use((req,res,next)=>
{
  res.status(404).json({
    "message":"Page not Found"
  })
})
// Server error  here 
app.use((error,req,res,next)=>
{
  res.status(404).json({
    "message":"Check your internet connection"
  })
})
module.exports = app;