const mongoose = require('mongoose');
const config = require('./config');


mongoose.connect(config.db.url)
.then(()=>
{
    console.log("MongoDB Atlas is connected");
})
.catch((error)=>{
    console.log(error.message);
    process.exit(1)
})